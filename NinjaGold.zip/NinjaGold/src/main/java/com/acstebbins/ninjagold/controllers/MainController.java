package com.acstebbins.ninjagold.controllers;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MainController {
	
	@RequestMapping("")
//	@GetMapping("")
	public String index() {
		return "redirect:/gold";
	}
	
	@RequestMapping("/gold")
//	@GetMapping("/gold")
	public String gold(HttpSession session) {
		if( session.getAttribute("nuggets") == null ) {
			session.setAttribute("nuggets", 0);
			ArrayList<String> log = new ArrayList<String>();
			session.setAttribute("log", log);
		}
		return "index.jsp";
	}
	
	@RequestMapping(value="/process_money", method=RequestMethod.POST)
//	@PostMapping("/process/money")
	public String process(@RequestParam(value="location") String location, HttpSession session) {
		
		int currentGold = (int) session.getAttribute("nuggets");
		ArrayList<String> log = (ArrayList<String>) session.getAttribute("log");
		
		if(location.equals("farm")) {
			int random_int = (int) ((Math.random() * (21 - 10)) + 10);
			currentGold += random_int;
			String act = "You've made " + random_int + " from farm";
			log.add(0, act);
//			System.out.println(random_int);
		}
		else if(location.equals("cave")) {
			int random_int = (int) ((Math.random() * (11 - 5)) + 5);
			currentGold += random_int;
			String act = "You've made " + random_int + " from cave";
			log.add(0, act);
//			System.out.println(random_int);
		}
		else if(location.equals("house")) {
			int random_int = (int) ((Math.random() * (6 - 2)) + 2);
			currentGold += random_int;
			String act = "You've made " + random_int + " from house";
			log.add(0, act);
//			System.out.println(random_int);
		}
		else if(location.equals("casino")) {
			int random_int = (int) ((Math.random() * (51 - -50)) + -50);
			currentGold += random_int;
			String act = "You've made " + random_int + " from casino";
			log.add(0, act);
//			System.out.println(random_int);
		}
		session.setAttribute("nuggets", currentGold);
		session.setAttribute("log", log);
		return "redirect:/gold";
	}
	
	@GetMapping("/destroy_session")
	public String clear(HttpSession session) {
		session.invalidate();
		return "redirect:/gold";
	}
}
